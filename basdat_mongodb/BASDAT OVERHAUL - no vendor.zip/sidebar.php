<div id="sidebar" class="sidebar p-3 bg-secondary">
    <div class="sidebar-logo">
        <p class="text-white">Politeknik Negeri Malang</p>
    </div>        
    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item">
            <a class="nav-link text-white" href="#">
                <img src="../../assets/icon/house-icon.svg" alt="" style="width: 20px; margin-right: 5px;">
                <span>Home</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="#">
                <img src="../../assets/icon/warning-icon.svg" alt="" style="width: 20px; margin-right: 5px;">
                <span>Report</span>
            </a>
        </li>
        <li class="nav